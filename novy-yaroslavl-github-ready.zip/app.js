const data = window.SITE_DATA || {properties:[],team:[],reviews:[]};
const $ = id => document.getElementById(id);
const fmt = n => Math.round(n).toLocaleString("ru-RU") + " ₽";

function renderProperties(list=data.properties){
  $("properties").innerHTML = list.map(p => `
    <article class="prop">
      <div class="ph"><span class="tag">${p.tag || "Объект"}</span>Фото объекта</div>
      <div class="body"><div class="price">${fmt(p.price)}</div><div class="addr">${p.address}, ${p.title}</div>
      <div class="meta">${(p.meta||[]).map(x=>`<span>${x}</span>`).join("")}</div></div>
    </article>`).join("");
  $("emptyProperties").classList.toggle("hidden", list.length !== 0);
}
function renderTeam(){
  $("teamList").innerHTML = data.team.map(m => `<div class="member"><div class="av">${m.initials || m.name.slice(0,2)}</div><div class="nm">${m.name}</div><div class="role">${m.role}</div></div>`).join("");
}
function renderReviews(){
  $("reviews").innerHTML = data.reviews.map(r => `<div class="rv"><div class="stars">★★★★★</div><p>${r.text}</p><div class="who">${r.who}</div></div>`).join("");
}
function search(){
  const type=$("searchType").value, district=$("searchDistrict").value;
  const from=+$("priceFrom").value||0, to=+$("priceTo").value||Infinity;
  const list=data.properties.filter(p=>(!type||p.type===type)&&(!district||p.district===district)&&p.price>=from&&p.price<=to);
  renderProperties(list);
  $("searchMessage").textContent = `Найдено объектов: ${list.length}`;
  document.querySelector("#objects").scrollIntoView({behavior:"smooth"});
}
$("searchForm").addEventListener("submit", e=>{e.preventDefault();search()});
$("resetCatalog").addEventListener("click",()=>{["searchType","searchDistrict","priceFrom","priceTo"].forEach(id=>$(id).value="");$("searchMessage").textContent="";renderProperties()});
document.querySelectorAll(".s-tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".s-tab").forEach(x=>x.classList.remove("on"));btn.classList.add("on")}));

function calc(){
  const cost=+$("cost").value, down=+$("down").value, rate=+$("rate").value, years=+$("term").value;
  $("vCost").textContent=fmt(cost);$("vDown").textContent=down+"%";$("vRate").textContent=rate+"%";$("vTerm").textContent=years;
  const loan=cost*(1-down/100), r=rate/100/12, n=years*12;
  const monthly=r===0?loan/n:loan*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
  $("rMonthly").textContent=fmt(monthly);$("rLoan").textContent=fmt(loan);$("rOver").textContent=fmt(monthly*n-loan);
}
["cost","down","rate","term"].forEach(id=>$(id).addEventListener("input",calc));
renderProperties();renderTeam();renderReviews();calc();